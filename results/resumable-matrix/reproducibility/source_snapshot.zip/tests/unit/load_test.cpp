#include <asr/benchmark/load.hpp>
#include <asr/engines/mock_engine.hpp>
#include <cmath>
#include <filesystem>
#include <iostream>
#include <stdexcept>
#include <unistd.h>

namespace {
void check(bool value, const char *message) {
    if (!value)
        throw std::runtime_error(message);
}
} // namespace
int main() {
    try {
        auto config = asr::resolve_config({}, {"audio.duration_ms=200", "audio.realtime_pacing=true",
                                               "workers.processes=2", "metrics.resource_sampling=false"});
        const auto root =
            std::filesystem::temp_directory_path() / ("asr_m6_load_" + std::to_string(getpid()));
        config.output_directory = root;
        asr::LoadSpec spec;
        spec.calls = 2;
        spec.concurrency = 2;
        spec.warmups = 1;
        spec.repetitions = 1;
        spec.languages = {"en", "id", "zh"};
        const auto first = asr::plan_load(config, spec, 3200, 4ULL * 1024 * 1024 * 1024);
        const auto second = asr::plan_load(config, spec, 3200, 4ULL * 1024 * 1024 * 1024);
        check(first.allowed && first.json()["calls"] == second.json()["calls"] && first.calls.size() == 4,
              "seeded load plan not reproducible");
        auto too_many = spec;
        too_many.concurrency = 3;
        const auto rejected = asr::plan_load(config, too_many, 3200, 4ULL * 1024 * 1024 * 1024);
        check(!rejected.allowed && !rejected.preflight["skip_reasons"].empty(),
              "worker capacity preflight failed");
        auto native_config = config;
        native_config.runtime = "qwen_native";
        native_config.audio_source = "wav";
        const auto memory_rejected = asr::plan_load(native_config, spec, 3200, 6ULL * 1024 * 1024 * 1024);
        check(!memory_rejected.allowed, "native memory preflight failed");
        auto shared = native_config;
        shared.runtime = "qwen_prefix";
        shared.worker_processes = 1;
        shared.max_sessions_per_process = 8;
        auto shared_spec = spec;
        shared_spec.concurrency = 8;
        const auto shared_plan = asr::plan_load(shared, shared_spec, 3200, 6ULL * 1024 * 1024 * 1024);
        check(shared_plan.allowed && shared_plan.preflight["active_call_slots"] == 8,
              "shared-model preflight multiplied model memory by call count");
        auto pool_config = shared;
        pool_config.worker_processes = 2;
        auto pool_plan = asr::plan_load(pool_config, shared_spec, 3200, 12ULL * 1024 * 1024 * 1024);
        check(pool_plan.allowed && pool_plan.preflight["active_call_slots"] == 16 &&
                  pool_plan.preflight["required_memory_bytes"].get<std::uint64_t>() >
                      shared_plan.preflight["required_memory_bytes"].get<std::uint64_t>(),
              "prefix pool memory estimate ignored additional model contexts");
        auto max_pool = shared;
        max_pool.worker_processes = 8;
        auto max_load = shared_spec;
        max_load.calls = 64;
        max_load.concurrency = 64;
        check(asr::plan_load(max_pool, max_load, 3200, 32ULL * 1024 * 1024 * 1024).allowed,
              "load runner cannot exercise all eight shared workers' 64 slots");
        max_load.concurrency = 65;
        bool upper_bound_rejected = false;
        try {
            (void)asr::plan_load(max_pool, max_load, 3200, 32ULL * 1024 * 1024 * 1024);
        } catch (const std::invalid_argument &) {
            upper_bound_rejected = true;
        }
        check(upper_bound_rejected, "load runner exceeded the 64-call bound");
        shared_spec.concurrency = 9;
        check(!asr::plan_load(shared, shared_spec, 3200, 6ULL * 1024 * 1024 * 1024).allowed,
              "shared-model preflight allowed excess call slots");
        shared_spec.concurrency = 1;
        check(!asr::plan_load(shared, shared_spec, 16000LL * 61, 6ULL * 1024 * 1024 * 1024).allowed,
              "shared-model preflight ignored the audio memory bound");
        auto network = spec;
        network.mode = "network";
        const auto network_plan = asr::plan_load(config, network, 3200, 4ULL * 1024 * 1024 * 1024);
        check(network_plan.allowed && network_plan.preflight["mode"] == "network",
              "network mode not explicitly planned");
        asr::WorkerLayout layout;
        layout.processes = 2;
        asr::SessionManager manager(layout,
                                    std::make_unique<asr::FactoryWorkerExecutor>(
                                        "in_process", [] { return std::make_unique<asr::MockEngine>(); }),
                                    std::make_unique<asr::RoundRobinScheduler>());
        const auto result = asr::run_load(config, manager, first, 3200, nullptr,
                                          {{"source", "synthetic"}, {"seed", config.seed}});
        check(result["status"] == "COMPLETE" && result["completed_calls"] == 4 &&
                  result["failed_calls"] == 0 && result["phases"].size() == 2 &&
                  result["phases"][0]["warmup"] == true && result["phases"][1]["warmup"] == false &&
                  result["metrics"]["offered_calls"] == 2 && result["metrics"]["completed_calls"] == 2 &&
                  result["slo"]["qualified"] == false,
              "mock load execution failed");
        auto mixed_spec = spec;
        mixed_spec.warmups = 0;
        mixed_spec.inputs = {{"en_fixture",
                              "en",
                              {},
                              std::make_shared<const std::vector<std::int16_t>>(1600, 1),
                              {{"recording_id", "en_fixture"}}},
                             {"id_fixture",
                              "id",
                              {},
                              std::make_shared<const std::vector<std::int16_t>>(3200, 2),
                              {{"recording_id", "id_fixture"}}}};
        const auto mixed_plan = asr::plan_load(config, mixed_spec, 0, 4ULL * 1024 * 1024 * 1024);
        check(mixed_plan.allowed && mixed_plan.calls[0].language == "en" &&
                  mixed_plan.calls[1].language == "id" &&
                  std::abs(mixed_plan.preflight["total_audio_seconds"].get<double>() - 0.3) < 1e-9,
              "manifest assignment or duration accounting incorrect");
        auto mixed_config = config;
        mixed_config.audio_source = "wav";
        const auto mixed =
            asr::run_load(mixed_config, manager, mixed_plan, 0, nullptr, nlohmann::json::object());
        check(mixed["status"] == "COMPLETE" &&
                  std::abs(mixed["metrics"]["completed_audio_seconds"].get<double>() - 0.3) < 1e-9,
              "distinct WAV input durations did not reach the C++ runner");
        auto strict = spec;
        strict.max_p95_final_ms = 1;
        const auto slo = asr::evaluate_load_slo(strict, result);
        check(!slo["thresholds_met"].get<bool>() && slo["violations"].size() == 1 &&
                  slo["violations"][0] == "p95_final_ms",
              "declared SLO did not detect final latency violation");
        auto zero_failures = spec;
        zero_failures.max_failure_rate = 0.0;
        check(asr::evaluate_load_slo(zero_failures, result)["profile_declared"] == true,
              "explicit zero-failure bound was treated as absent");
        auto large_mock = result;
        large_mock["metrics"]["offered_calls"] = 20;
        check(asr::evaluate_load_slo(zero_failures, large_mock)["qualified"] == false,
              "mock load was incorrectly qualified as capacity evidence");
        const auto a = result["phases"][1]["calls"][0]["summary"]["worker_id"].get<std::string>();
        const auto b = result["phases"][1]["calls"][1]["summary"]["worker_id"].get<std::string>();
        check(a != b, "concurrent calls did not use separate workers");
        check(std::filesystem::exists(std::filesystem::path(result["directory"].get<std::string>()) /
                                      "plan.json"),
              "load plan artifact missing");
        std::filesystem::remove_all(root);
        std::cout << "M6 deterministic plan, preflight and concurrent mock load passed\n";
        return 0;
    } catch (const std::exception &error) {
        std::cerr << error.what() << '\n';
        return 1;
    }
}
